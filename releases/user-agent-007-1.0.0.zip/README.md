# User-Agent 007

Tired of having to switch over to another browser just to access a specific web app that doesn't support Opera?

So was I! Then, I created User-Agent 007.

**This extension is even cool than its name!**

Use this extension to easily assign user-agents to specific websites.

[![Beerpay](https://beerpay.io/DougBeney/User-Agent-007-Opera-Extension/badge.svg)](https://beerpay.io/DougBeney/User-Agent-007-Opera-Extension)

[Download On The Opera Web Store](#) (Under moderation. Upload the zip in /releases if you are super eager.)

## Screenshots

![Screenshot 1](screenshots/screen_1.png)
![Screenshot 2](screenshots/screen_2.png)
![Screenshot 3](screenshots/screen_3.png)

[Download On The Opera Web Store](#) (Coming Soon!)

[![Beerpay](https://beerpay.io/DougBeney/User-Agent-007-Opera-Extension/badge.svg)](https://beerpay.io/DougBeney/User-Agent-007-Opera-Extension)

These :fire: lines of code were carefully created by [Doug Beney](https://dougbeney.com/)
